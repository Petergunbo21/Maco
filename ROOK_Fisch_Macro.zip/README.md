# THE ROOK Fisch Macro (Android source)

A native Android companion app source project with a GitHub Actions APK build workflow.

## Current capability
- Uses Android AccessibilityService gesture dispatch (user must explicitly enable it).
- Sends a configurable hold-and-release cast gesture at the screen center/lower area.
- Sends one configurable hold-and-release cast per start request; start it again after manually finishing the catch.
- Does not inject code into Roblox, read game memory, or bypass anti-cheat.

## Important Fisch limitation
Fisch's fishing flow includes a SHAKE button that appears at changing screen positions and a reel minigame where the player must keep the moving fish indicator inside the white control bar. This source does **not** use computer vision or image recognition, so it cannot reliably find SHAKE or automatically track the fish bar. You must tap SHAKE and play the reel stage yourself. The cast location and timing may need adjustment for the device/UI layout. Do not treat this as a fully automatic fishing bot.

## Build APK on Android using GitHub
1. Create a GitHub repository and upload the contents of this folder (not the parent folder).
2. Open the repository's **Actions** tab.
3. Run **Build ROOK Fisch Macro APK** (or push to main/master).
4. Open the workflow run and download the `ROOK-Fisch-Macro-debug` artifact.
5. Extract the artifact ZIP and install `app-debug.apk`. Android may ask to allow installation from the browser/files app.
6. Open THE ROOK and enable its accessibility service in Android Settings.

## Use
1. Open Roblox Fisch and stand facing water with a rod equipped.
2. Open THE ROOK and set the cast hold duration.
3. Enable accessibility, return to THE ROOK, and start the assist.
4. Switch to Fisch during the five-second start delay. The app sends one cast gesture. Tap the changing SHAKE prompt and complete the reel minigame manually. Start another cast from THE ROOK after landing the fish.
5. This initial build does not provide a floating stop bubble; the one-shot gesture ends automatically.

## Notes
- Source project only; an APK has not been built or device-tested in this workspace.
- Android battery/background restrictions and Roblox UI scaling may affect operation.
- Use only where permitted by the game/platform rules.


## ROOK AI Advisor — new development memory

- Saves issue reports and test notes locally in app-private SharedPreferences.
- Each entry can be marked `STILL HAPPENING` or `FIXED` after a new APK update/test.
- Builds a copyable improvement request containing the saved history so it can be sent back to ChatGPT.
- Adds provider slots for Google Gemini, OpenAI, Anthropic Claude, and OpenAI-compatible services.
- API keys are encrypted with AES-GCM using a key held in Android Keystore.

**Important limitation:** this version is a local development journal and encrypted key vault, not a live multi-provider AI client yet. It does not transmit keys or call provider APIs. Provider API connections, AI-generated diagnostics, and automated screen recognition/reeling still need implementation and testing.

### Update persistence
The history is kept across normal APK updates when the package ID (`com.therook.fischmacro`) and signing identity remain the same. Do not uninstall the app or clear its storage if you want to keep the journal. Export/copy important notes before reinstalling.
