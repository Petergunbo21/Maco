package com.therook.fischmacro;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.os.Handler;
import android.os.Looper;
import android.content.Intent;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Toast;

public class RookAccessibilityService extends AccessibilityService {
    private final Handler handler=new Handler(Looper.getMainLooper());
    private volatile boolean running=false;
    private int cast=700;
    @Override public void onAccessibilityEvent(AccessibilityEvent e){}
    @Override public void onInterrupt(){ stopMacro(); }
    @Override protected void onServiceConnected(){ super.onServiceConnected(); }
    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent!=null && "START".equals(intent.getAction())){
            cast=intent.getIntExtra("cast",700); running=true;
            handler.removeCallbacksAndMessages(null); handler.postDelayed(this::cycle,5000);
            Toast.makeText(this,"ROOK: switch to Fisch now",Toast.LENGTH_LONG).show();
        } else if(intent!=null && "STOP".equals(intent.getAction())) stopMacro();
        return START_STICKY;
    }
    private void cycle(){
        if(!running)return;
        float x=getResources().getDisplayMetrics().widthPixels/2f;
        float y=getResources().getDisplayMetrics().heightPixels*0.72f;
        Path p=new Path(); p.moveTo(x,y);
        GestureDescription.StrokeDescription stroke=new GestureDescription.StrokeDescription(p,0,cast);
        dispatchGesture(new GestureDescription.Builder().addStroke(stroke).build(),new GestureResultCallback(){
            @Override public void onCompleted(GestureDescription g){ running=false; handler.postDelayed(()->Toast.makeText(RookAccessibilityService.this,"Cast sent. Tap SHAKE and complete the reel manually. Start again after landing the fish.",Toast.LENGTH_LONG).show(),250); }
            @Override public void onCancelled(GestureDescription g){ running=false; Toast.makeText(RookAccessibilityService.this,"Cast gesture cancelled",Toast.LENGTH_SHORT).show(); }
        },null);
    }
    private void stopMacro(){ running=false; handler.removeCallbacksAndMessages(null); Toast.makeText(this,"ROOK stopped",Toast.LENGTH_SHORT).show(); }
}
