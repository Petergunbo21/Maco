package com.therook.fischmacro;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.*;
import android.graphics.Color;
import android.content.SharedPreferences;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.security.keystore.KeyGenParameterSpec;
import android.security.keystore.KeyProperties;
import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.GCMParameterSpec;
import android.util.Base64;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends Activity {
    EditText castMs, issueInput, keyInput;
    TextView status, historyView, promptView;
    Spinner providerSpinner;
    SharedPreferences prefs;
    int dp(float v){ return (int)(v*getResources().getDisplayMetrics().density); }
    TextView text(String s,int size){ TextView t=new TextView(this); t.setText(s); t.setTextColor(Color.WHITE); t.setTextSize(size); return t; }
    Button button(String s){ Button b=new Button(this); b.setText(s); b.setAllCaps(false); return b; }
    EditText field(String hint,String value, boolean numeric){ EditText e=new EditText(this); e.setSingleLine(true); e.setHint(hint); e.setText(value); e.setTextColor(Color.WHITE); e.setHintTextColor(0xff91a0b8); e.setInputType(numeric?2:1); e.setPadding(dp(12),0,dp(12),0); e.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff55b7ff)); return e; }
    void gap(LinearLayout l,int h){ View v=new View(this); l.addView(v,new LinearLayout.LayoutParams(1,dp(h))); }
    @Override public void onCreate(Bundle b){ super.onCreate(b);
        prefs=getSharedPreferences("rook_advisor_history",MODE_PRIVATE);
        ScrollView scroll=new ScrollView(this); LinearLayout root=new LinearLayout(this); root.setOrientation(1); root.setPadding(dp(20),dp(24),dp(20),dp(24)); root.setBackgroundColor(0xff080d18); scroll.addView(root);
        TextView title=text("THE ROOK",28); title.setTypeface(null,1); root.addView(title);
        TextView sub=text("FISCH MACRO  •  ANDROID",13); sub.setTextColor(0xff55b7ff); root.addView(sub);
        TextView info=text("Fishing companion: cast assistance plus a development journal that remembers problems and test results.",15); info.setPadding(0,dp(18),0,dp(14)); root.addView(info);
        TextView warning=text("CURRENT MACRO STATUS: assisted timed gestures only. Automatic SHAKE recognition and adaptive fish-bar tracking are not implemented in this build.",13); warning.setTextColor(0xffffca75); warning.setPadding(dp(12),dp(12),dp(12),dp(12)); warning.setBackgroundColor(0xff20202a); root.addView(warning);
        root.addView(text("Cast hold duration (milliseconds)",14)); castMs=field("Example: 700","700",true); root.addView(castMs);
        Button access=button("1. ENABLE ROOK ACCESSIBILITY"); access.setOnClickListener(v->startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))); root.addView(access);
        Button start=button("2. START CAST ASSIST"); start.setOnClickListener(v->{
            int c=parse(castMs,700,100,5000);
            Intent i=new Intent(this,RookAccessibilityService.class); i.setAction("START"); i.putExtra("cast",c); startService(i);
            status.setText("Macro queued. Switch to Fisch within 5 seconds. Use floating STOP to end it.");
        }); root.addView(start);
        Button stop=button("STOP MACRO"); stop.setOnClickListener(v->{ Intent i=new Intent(this,RookAccessibilityService.class); i.setAction("STOP"); startService(i); status.setText("Stop requested."); }); root.addView(stop);
        status=text("Status: idle",13); status.setPadding(0,dp(14),0,dp(14)); root.addView(status);
        gap(root,16); section(root,"ROOK AI ADVISOR • DEVELOPMENT MEMORY");
        root.addView(text("Describe what happened, what you expected, and whether the problem still happens after an update. This journal stays on this device.",13));
        issueInput=new EditText(this); issueInput.setHint("Example: fish bar moves too fast with my new rod..."); issueInput.setTextColor(Color.WHITE); issueInput.setHintTextColor(0xff91a0b8); issueInput.setMinLines(3); issueInput.setGravity(Gravity.TOP); issueInput.setPadding(dp(12),dp(10),dp(12),dp(10)); issueInput.setBackgroundColor(0xff182338); root.addView(issueInput);
        Button save=button("SAVE TEST / PROBLEM"); save.setOnClickListener(v->saveIssue()); root.addView(save);
        Button still=button("MARK LAST PROBLEM: STILL HAPPENING"); still.setOnClickListener(v->markLast("STILL HAPPENING")); root.addView(still);
        Button fixed=button("MARK LAST PROBLEM: FIXED"); fixed.setOnClickListener(v->markLast("FIXED")); root.addView(fixed);
        Button history=button("REFRESH HISTORY"); history.setOnClickListener(v->showHistory()); root.addView(history);
        historyView=text("",13); historyView.setTextColor(0xffc5d4e8); historyView.setPadding(dp(10),dp(10),dp(10),dp(10)); historyView.setBackgroundColor(0xff121d2e); root.addView(historyView); showHistory();
        Button prompt=button("MAKE A MESSAGE TO SEND THE ROOK"); prompt.setOnClickListener(v->makePrompt()); root.addView(prompt);
        promptView=text("",13); promptView.setTextColor(0xffd8e7f7); promptView.setPadding(dp(10),dp(10),dp(10),dp(10)); promptView.setBackgroundColor(0xff121d2e); root.addView(promptView);
        Button copy=button("COPY IMPROVEMENT MESSAGE"); copy.setOnClickListener(v->{ if(promptView.getText().length()>0){ ClipboardManager cm=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE); cm.setPrimaryClip(ClipData.newPlainText("ROOK improvement request",promptView.getText())); Toast.makeText(this,"Copied",Toast.LENGTH_SHORT).show(); }}); root.addView(copy);
        gap(root,16); section(root,"AI PROVIDER KEY VAULT");
        root.addView(text("Provider slots for Gemini and other AI services. Keys entered here are encrypted with an Android Keystore key and stay on this device. This version saves keys securely but does not yet send requests to provider APIs.",12));
        providerSpinner=new Spinner(this); String[] providers={"Google Gemini","OpenAI","Anthropic Claude","Other OpenAI-compatible"}; ArrayAdapter<String> ad=new ArrayAdapter<>(this,android.R.layout.simple_spinner_item,providers); ad.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item); providerSpinner.setAdapter(ad); root.addView(providerSpinner);
        keyInput=field("Paste API key", "", false); keyInput.setInputType(129); root.addView(keyInput);
        Button saveKey=button("SAVE ENCRYPTED PROVIDER KEY"); saveKey.setOnClickListener(v->saveKey()); root.addView(saveKey);
        Button clearKey=button("DELETE SELECTED PROVIDER KEY"); clearKey.setOnClickListener(v->deleteKey()); root.addView(clearKey);
        TextView footer=text("History is stored in app-private storage and normally survives APK updates when the same application ID and signing key are used. Uninstalling the app or clearing its data deletes it. Export important notes before reinstalling.",12); footer.setTextColor(0xff9aa8bd); footer.setPadding(0,dp(18),0,0); root.addView(footer);
        setContentView(scroll);
    }
    void section(LinearLayout root,String s){ TextView t=text(s,17); t.setTypeface(null,1); t.setTextColor(0xff55b7ff); root.addView(t); gap(root,8); }
    int parse(EditText e,int d,int min,int max){ try{return Math.max(min,Math.min(max,Integer.parseInt(e.getText().toString().trim())));}catch(Exception ex){return d;} }
    String stamp(){ return new SimpleDateFormat("yyyy-MM-dd HH:mm",Locale.getDefault()).format(new Date()); }
    void saveIssue(){ String note=issueInput.getText().toString().trim(); if(note.isEmpty()){ issueInput.setError("Describe the issue or test first"); return; }
        String old=prefs.getString("history",""); String entry="["+stamp()+"] [NEW / UNVERIFIED] "+note;
        prefs.edit().putString("history",entry+"\n\n"+old).apply(); issueInput.setText(""); showHistory(); Toast.makeText(this,"Saved on this device",Toast.LENGTH_SHORT).show(); }
    void markLast(String state){ String h=prefs.getString("history",""); if(h.isEmpty()){Toast.makeText(this,"No saved issue yet",Toast.LENGTH_SHORT).show();return;}
        int end=h.indexOf("\n\n"); String first=end<0?h:h.substring(0,end); String rest=end<0?"":h.substring(end);
        first=first.replaceFirst("\\[(NEW / UNVERIFIED|STILL HAPPENING|FIXED)\\]","["+state+"]");
        prefs.edit().putString("history",first+rest).apply(); showHistory(); }
    void showHistory(){ String h=prefs.getString("history",""); historyView.setText(h.isEmpty()?"No saved tests yet. Save a problem or test above.":h); }
    void makePrompt(){ String h=prefs.getString("history",""); if(h.isEmpty()){promptView.setText("Save a test or problem first.");return;}
        promptView.setText("Please improve THE ROOK Fisch Android macro using this device's test history. Compare the latest result with older entries, identify which problems are still happening versus fixed, and suggest the smallest testable code changes. Do not claim a fix is verified without a new test.\\n\\nDEVICE HISTORY:\\n"+h);
    }
    String alias(){ return "rook_"+providerSpinner.getSelectedItemPosition(); }
    void saveKey(){ String key=keyInput.getText().toString().trim(); if(key.isEmpty()){keyInput.setError("Paste a key first");return;} try{
        String enc=encrypt(key); prefs.edit().putString(alias(),enc).apply(); keyInput.setText(""); Toast.makeText(this,"Encrypted key saved for "+providerSpinner.getSelectedItem(),Toast.LENGTH_LONG).show();
    }catch(Exception e){Toast.makeText(this,"Could not encrypt key: "+e.getMessage(),Toast.LENGTH_LONG).show();}}
    void deleteKey(){ prefs.edit().remove(alias()).apply(); keyInput.setText(""); Toast.makeText(this,"Saved key deleted",Toast.LENGTH_SHORT).show(); }
    SecretKey getSecret() throws Exception { java.security.KeyStore ks=java.security.KeyStore.getInstance("AndroidKeyStore"); ks.load(null); if(ks.containsAlias("ROOK_ADVISOR_AES")) return (SecretKey)ks.getKey("ROOK_ADVISOR_AES",null);
        KeyGenerator kg=KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES,"AndroidKeyStore"); kg.init(new KeyGenParameterSpec.Builder("ROOK_ADVISOR_AES",KeyProperties.PURPOSE_ENCRYPT|KeyProperties.PURPOSE_DECRYPT).setBlockModes(KeyProperties.BLOCK_MODE_GCM).setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE).build()); return kg.generateKey(); }
    String encrypt(String plain) throws Exception { Cipher c=Cipher.getInstance("AES/GCM/NoPadding"); c.init(Cipher.ENCRYPT_MODE,getSecret()); byte[] iv=c.getIV(), data=c.doFinal(plain.getBytes(StandardCharsets.UTF_8)); return Base64.encodeToString(iv,Base64.NO_WRAP)+"."+Base64.encodeToString(data,Base64.NO_WRAP); }
}
