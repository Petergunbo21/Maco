package com.therook.fischmacro;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Color;
import android.graphics.Path;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.util.DisplayMetrics;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.accessibility.AccessibilityEvent;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

public class RookAccessibilityService extends AccessibilityService {
    public static volatile RookAccessibilityService instance;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private WindowManager windowManager;
    private WindowManager.LayoutParams windowParams;
    private FrameLayout windowRoot;
    private LinearLayout expandedPanel;
    private TextView bubble;
    private TextView stateView;
    private boolean running = false;
    private boolean paused = false;
    private int xPercent = 50, yPercent = 80, holdMs = 700, intervalMs = 5000;
    private int countdown = 5;

    private final Runnable castLoop = new Runnable() {
        @Override public void run() {
            if (!running || paused) return;
            sendCastGesture();
            setStatus("RUNNING  ·  CAST SENT", Color.rgb(120, 226, 170));
            handler.postDelayed(this, intervalMs);
        }
    };

    private final Runnable countdownTick = new Runnable() {
        @Override public void run() {
            if (!running || paused) return;
            if (countdown > 0) {
                setStatus("SWITCH TO FISCH  ·  " + countdown + "s", Color.rgb(255, 194, 105));
                countdown--;
                handler.postDelayed(this, 1000);
            } else {
                handler.removeCallbacks(castLoop);
                castLoop.run();
            }
        }
    };

    @Override public void onServiceConnected() {
        super.onServiceConnected();
        instance = this;
        windowManager = (WindowManager)getSystemService(WINDOW_SERVICE);
        reloadSettings();
        // Create the accessibility overlay immediately when Android connects the service.
        showPanel();
    }

    public void reloadSettings() {
        android.content.SharedPreferences p = getSharedPreferences("rook_settings", MODE_PRIVATE);
        xPercent = clamp(p.getInt("x", 50), 0, 100);
        yPercent = clamp(p.getInt("y", 80), 0, 100);
        holdMs = clamp(p.getInt("hold", 700), 50, 2500);
        intervalMs = clamp(p.getInt("interval", 5000), 1500, 60000);
    }

    public boolean isRunning() { return running && !paused; }

    public void showPanel() {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            handler.post(this::showPanel);
            return;
        }
        if (windowManager == null) windowManager = (WindowManager)getSystemService(WINDOW_SERVICE);
        if (windowRoot != null) {
            windowRoot.setVisibility(View.VISIBLE);
            return;
        }

        windowRoot = new FrameLayout(this);
        expandedPanel = new LinearLayout(this);
        expandedPanel.setOrientation(LinearLayout.VERTICAL);
        expandedPanel.setPadding(dp(12), dp(10), dp(12), dp(12));
        expandedPanel.setBackground(rounded(Color.rgb(17, 23, 36), 18, Color.rgb(58, 79, 111)));
        LinearLayout header = new LinearLayout(this);
        header.setGravity(Gravity.CENTER_VERTICAL);
        header.setOrientation(LinearLayout.HORIZONTAL);
        header.setPadding(dp(3), dp(2), dp(2), dp(8));
        TextView brand = label("THE ROOK", 15, Color.WHITE, true);
        header.addView(brand, new LinearLayout.LayoutParams(0, dp(34), 1));
        TextView minimize = label("—", 21, Color.rgb(160, 190, 225), true);
        minimize.setGravity(Gravity.CENTER);
        header.addView(minimize, new LinearLayout.LayoutParams(dp(36), dp(34)));
        minimize.setOnClickListener(v -> collapsePanel());
        header.setOnTouchListener(new View.OnTouchListener() {
            float downX, downY; int startX, startY;
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() == MotionEvent.ACTION_DOWN) {
                    downX = e.getRawX(); downY = e.getRawY();
                    startX = windowParams.x; startY = windowParams.y; return true;
                }
                if (e.getAction() == MotionEvent.ACTION_MOVE) {
                    windowParams.x = startX + (int)(e.getRawX() - downX);
                    windowParams.y = startY + (int)(e.getRawY() - downY);
                    try { windowManager.updateViewLayout(windowRoot, windowParams); } catch (Exception ignored) {}
                    return true;
                }
                return e.getAction() == MotionEvent.ACTION_UP;
            }
        });
        expandedPanel.addView(header);

        TextView sub = label("FISCH  /  FLOATING MACRO", 10, Color.rgb(111, 183, 255), true);
        sub.setLetterSpacing(.08f);
        expandedPanel.addView(sub);
        stateView = label("READY  ·  TAP START", 12, Color.rgb(120, 226, 170), true);
        LinearLayout.LayoutParams statusLp = new LinearLayout.LayoutParams(-1, dp(34));
        statusLp.topMargin = dp(8);
        expandedPanel.addView(stateView, statusLp);

        Button cast = macroButton("CAST ONCE", Color.rgb(38, 54, 78));
        addButton(expandedPanel, cast);
        cast.setOnClickListener(v -> { reloadSettings(); sendCastGesture(); setStatus("CAST GESTURE SENT", Color.rgb(120, 226, 170)); });

        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        Button start = macroButton("START", Color.rgb(35, 122, 87));
        Button pause = macroButton("PAUSE", Color.rgb(80, 91, 115));
        row.addView(start, new LinearLayout.LayoutParams(0, dp(44), 1));
        LinearLayout.LayoutParams pauseLp = new LinearLayout.LayoutParams(0, dp(44), 1);
        pauseLp.leftMargin = dp(7);
        row.addView(pause, pauseLp);
        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(-1, dp(44));
        rowLp.topMargin = dp(7);
        expandedPanel.addView(row, rowLp);
        start.setOnClickListener(v -> startCountdown());
        pause.setOnClickListener(v -> togglePause());

        Button stop = macroButton("STOP MACRO", Color.rgb(150, 45, 58));
        addButton(expandedPanel, stop);
        stop.setOnClickListener(v -> stopMacro());

        TextView foot = label("Drag this header to move  ·  — to minimize", 10, Color.rgb(154, 169, 191), false);
        LinearLayout.LayoutParams footLp = new LinearLayout.LayoutParams(-1, dp(22));
        footLp.topMargin = dp(5);
        expandedPanel.addView(foot, footLp);

        bubble = label("ROOK  ·  OPEN", 12, Color.WHITE, true);
        bubble.setGravity(Gravity.CENTER);
        bubble.setPadding(dp(16), dp(11), dp(16), dp(11));
        bubble.setBackground(rounded(Color.rgb(28, 44, 67), 28, Color.rgb(76, 151, 220)));
        bubble.setVisibility(View.GONE);
        bubble.setOnClickListener(v -> expandPanel());

        windowRoot.addView(expandedPanel, new FrameLayout.LayoutParams(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.START));
        windowRoot.addView(bubble, new FrameLayout.LayoutParams(WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.START));
        windowParams = new WindowManager.LayoutParams(
                dp(268), WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        windowParams.gravity = Gravity.TOP | Gravity.START;
        windowParams.x = dp(12);
        windowParams.y = dp(130);
        try {
            windowManager.addView(windowRoot, windowParams);
        } catch (Exception ex) {
            windowRoot = null;
            expandedPanel = null;
            bubble = null;
            stateView = null;
            android.util.Log.e("THE_ROOK", "Unable to create accessibility overlay", ex);
        }
    }

    private void collapsePanel() {
        if (expandedPanel != null) expandedPanel.setVisibility(View.GONE);
        if (bubble != null) bubble.setVisibility(View.VISIBLE);
        if (windowParams != null && windowRoot != null) {
            windowParams.width = WindowManager.LayoutParams.WRAP_CONTENT;
            try { windowManager.updateViewLayout(windowRoot, windowParams); } catch (Exception ignored) {}
        }
    }

    private void expandPanel() {
        if (bubble != null) bubble.setVisibility(View.GONE);
        if (expandedPanel != null) expandedPanel.setVisibility(View.VISIBLE);
        if (windowParams != null && windowRoot != null) {
            windowParams.width = dp(268);
            try { windowManager.updateViewLayout(windowRoot, windowParams); } catch (Exception ignored) {}
        }
    }

    public void startCountdown() {
        showPanel();
        reloadSettings();
        stopMacro();
        running = true;
        paused = false;
        countdown = 5;
        if (expandedPanel != null && expandedPanel.getVisibility() != View.VISIBLE) expandPanel();
        handler.post(countdownTick);
    }

    private void togglePause() {
        if (!running) { setStatus("NOT RUNNING", Color.LTGRAY); return; }
        paused = !paused;
        handler.removeCallbacks(castLoop);
        handler.removeCallbacks(countdownTick);
        if (paused) setStatus("PAUSED", Color.rgb(255, 194, 105));
        else {
            countdown = 0;
            setStatus("RESUMING", Color.rgb(120, 226, 170));
            handler.post(castLoop);
        }
    }

    public void stopMacro() {
        running = false;
        paused = false;
        handler.removeCallbacks(countdownTick);
        handler.removeCallbacks(castLoop);
        setStatus("STOPPED", Color.rgb(255, 145, 145));
    }

    private void sendCastGesture() {
        if (windowManager == null) return;
        DisplayMetrics metrics = new DisplayMetrics();
        windowManager.getDefaultDisplay().getRealMetrics(metrics);
        float x = metrics.widthPixels * (xPercent / 100f);
        float y = metrics.heightPixels * (yPercent / 100f);
        Path path = new Path();
        path.moveTo(x, y);
        GestureDescription gesture = new GestureDescription.Builder()
                .addStroke(new GestureDescription.StrokeDescription(path, 0, holdMs)).build();
        boolean accepted = dispatchGesture(gesture, new GestureResultCallback() {
            @Override public void onCompleted(GestureDescription g) {
                if (running && !paused) setStatus("RUNNING  ·  CAST SENT", Color.rgb(120, 226, 170));
            }
            @Override public void onCancelled(GestureDescription g) {
                setStatus("GESTURE CANCELLED", Color.rgb(255, 145, 145));
            }
        }, handler);
        if (!accepted) setStatus("GESTURE NOT ACCEPTED", Color.rgb(255, 145, 145));
    }

    private void setStatus(String text, int color) {
        if (stateView != null) {
            stateView.setText(text);
            stateView.setTextColor(color);
        }
    }

    private Button macroButton(String text, int color) {
        Button b = new Button(this);
        b.setText(text);
        b.setTextSize(12);
        b.setTextColor(Color.WHITE);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setAllCaps(false);
        b.setStateListAnimator(null);
        b.setBackground(rounded(color, 11, color));
        return b;
    }

    private void addButton(LinearLayout parent, Button b) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(44));
        lp.topMargin = dp(7);
        parent.addView(b, lp);
    }

    private TextView label(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private GradientDrawable rounded(int fill, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(dp(radius));
        d.setStroke(dp(1), stroke);
        return d;
    }

    private int dp(float v) { return (int)(v * getResources().getDisplayMetrics().density + .5f); }
    private int clamp(int v, int min, int max) { return Math.max(min, Math.min(max, v)); }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) { }
    @Override public void onInterrupt() { stopMacro(); }

    @Override public void onDestroy() {
        stopMacro();
        if (windowRoot != null && windowManager != null) {
            try { windowManager.removeView(windowRoot); } catch (Exception ignored) {}
        }
        windowRoot = null;
        instance = null;
        super.onDestroy();
    }
}
