package com.therook.fischmacro;

import android.app.Activity;
import android.content.ComponentName;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int BG = Color.rgb(10, 14, 24);
    private static final int CARD = Color.rgb(21, 29, 45);
    private static final int CARD2 = Color.rgb(27, 38, 58);
    private static final int TEXT = Color.rgb(242, 246, 255);
    private static final int MUTED = Color.rgb(157, 174, 199);
    private static final int BLUE = Color.rgb(73, 163, 246);
    private static final int RED = Color.rgb(195, 52, 67);
    private android.content.SharedPreferences prefs;
    private EditText xInput, yInput, holdInput, intervalInput;
    private TextView serviceState, macroState, journalHistory;
    private EditText issueInput;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(BG);
        getWindow().setNavigationBarColor(BG);
        getWindow().getDecorView().setSystemUiVisibility(0);
        prefs = getSharedPreferences("rook_settings", MODE_PRIVATE);
        buildScreen();
    }

    @Override protected void onResume() {
        super.onResume();
        refreshServiceState();
    }

    private void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(BG);
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(20), dp(22), dp(20), dp(28));
        scroll.addView(page);

        TextView eyebrow = text("FISCH MACRO  /  ANDROID", 12, BLUE, true);
        eyebrow.setLetterSpacing(.12f);
        page.addView(eyebrow);
        TextView title = text("THE ROOK", 34, TEXT, true);
        title.setTypeface(Typeface.create("sans-serif-black", Typeface.NORMAL));
        LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(-1, -2);
        titleLp.topMargin = dp(5);
        page.addView(title, titleLp);
        TextView intro = text("A floating fishing companion for Roblox Fisch.", 15, MUTED, false);
        LinearLayout.LayoutParams introLp = new LinearLayout.LayoutParams(-1, -2);
        introLp.topMargin = dp(7);
        introLp.bottomMargin = dp(18);
        page.addView(intro, introLp);

        LinearLayout statusCard = card(page);
        TextView cardTitle = text("SYSTEM STATUS", 12, BLUE, true);
        cardTitle.setLetterSpacing(.08f);
        statusCard.addView(cardTitle);
        serviceState = text("ACCESSIBILITY SERVICE: CHECKING", 14, TEXT, true);
        LinearLayout.LayoutParams stateLp = new LinearLayout.LayoutParams(-1, -2);
        stateLp.topMargin = dp(10);
        statusCard.addView(serviceState, stateLp);
        macroState = text("MACRO: STOPPED", 13, MUTED, false);
        LinearLayout.LayoutParams macroLp = new LinearLayout.LayoutParams(-1, -2);
        macroLp.topMargin = dp(5);
        statusCard.addView(macroState, macroLp);

        LinearLayout settings = card(page);
        TextView settingsTitle = text("CAST SETTINGS", 15, TEXT, true);
        settings.addView(settingsTitle);
        TextView help = text("Tune the tap position to match the Fisch cast button. Values are percentages of your screen.", 12, MUTED, false);
        LinearLayout.LayoutParams helpLp = new LinearLayout.LayoutParams(-1, -2);
        helpLp.topMargin = dp(5);
        settings.addView(help, helpLp);

        xInput = input(settings, "Cast X position (0–100%)", prefs.getInt("x", 50));
        yInput = input(settings, "Cast Y position (0–100%)", prefs.getInt("y", 80));
        holdInput = input(settings, "Cast hold duration (ms)", prefs.getInt("hold", 700));
        intervalInput = input(settings, "Repeat interval (ms, minimum 1500)", prefs.getInt("interval", 5000));

        Button save = actionButton("SAVE SETTINGS", BLUE, TEXT);
        LinearLayout.LayoutParams saveLp = new LinearLayout.LayoutParams(-1, dp(48));
        saveLp.topMargin = dp(12);
        settings.addView(save, saveLp);
        save.setOnClickListener(v -> { saveSettings(); Toast.makeText(this, "Settings saved", Toast.LENGTH_SHORT).show(); });

        LinearLayout actions = card(page);
        TextView actionsTitle = text("MACRO CONTROLS", 15, TEXT, true);
        actions.addView(actionsTitle);
        TextView actionsHelp = text("Enable the service once. Then open the floating panel over Fisch.", 12, MUTED, false);
        LinearLayout.LayoutParams ah = new LinearLayout.LayoutParams(-1, -2);
        ah.topMargin = dp(5);
        ah.bottomMargin = dp(12);
        actions.addView(actionsHelp, ah);

        Button enable = actionButton("1  ·  ENABLE ACCESSIBILITY", CARD2, TEXT);
        addButton(actions, enable);
        enable.setOnClickListener(v -> startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)));

        Button show = actionButton("2  ·  SHOW FLOATING PANEL", CARD2, TEXT);
        addButton(actions, show);
        show.setOnClickListener(v -> {
            saveSettings();
            if (RookAccessibilityService.instance != null) {
                RookAccessibilityService.instance.showPanel();
                Toast.makeText(this, "ROOK panel displayed", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Enable ROOK in Accessibility settings, then return here", Toast.LENGTH_LONG).show();
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            }
        });

        Button start = actionButton("START CAST ASSIST", BLUE, Color.WHITE);
        addButton(actions, start);
        start.setOnClickListener(v -> {
            saveSettings();
            if (RookAccessibilityService.instance == null) {
                Toast.makeText(this, "Enable ROOK Accessibility first", Toast.LENGTH_LONG).show();
                startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
                return;
            }
            RookAccessibilityService.instance.startCountdown();
            macroState.setText("MACRO: STARTING — SWITCH TO FISCH");
        });

        Button stop = actionButton("STOP MACRO", RED, Color.WHITE);
        addButton(actions, stop);
        stop.setOnClickListener(v -> {
            if (RookAccessibilityService.instance != null) RookAccessibilityService.instance.stopMacro();
            macroState.setText("MACRO: STOPPED");
        });

        LinearLayout note = card(page);
        TextView noteTitle = text("WHAT THIS BUILD DOES", 13, BLUE, true);
        note.addView(noteTitle);
        TextView noteBody = text("ROOK can send a timed cast gesture at the position you configure. It does not yet recognize SHAKE prompts or track the moving fish bar, so those steps still need manual input. Test your cast position before starting a loop.", 12, MUTED, false);
        LinearLayout.LayoutParams nb = new LinearLayout.LayoutParams(-1, -2);
        nb.topMargin = dp(8);
        note.addView(noteBody, nb);

        LinearLayout journal = card(page);
        TextView journalTitle = text("ROOK AI ADVISOR  ·  DEVELOPMENT MEMORY", 15, TEXT, true);
        journal.addView(journalTitle);
        TextView journalHelp = text("Save what happened, what you expected, and whether the problem is still happening. Entries stay on this device.", 12, MUTED, false);
        LinearLayout.LayoutParams jh = new LinearLayout.LayoutParams(-1, -2);
        jh.topMargin = dp(5);
        journal.addView(journalHelp, jh);
        issueInput = new EditText(this);
        issueInput.setHint("Example: Cast button did not respond after switching to Fisch...");
        issueInput.setHintTextColor(MUTED);
        issueInput.setTextColor(TEXT);
        issueInput.setTextSize(14);
        issueInput.setGravity(Gravity.TOP | Gravity.START);
        issueInput.setMinLines(3);
        issueInput.setPadding(dp(12), dp(10), dp(12), dp(10));
        issueInput.setBackground(shape(CARD2, 10));
        LinearLayout.LayoutParams issueLp = new LinearLayout.LayoutParams(-1, dp(105));
        issueLp.topMargin = dp(10);
        journal.addView(issueInput, issueLp);
        Button saveIssue = actionButton("SAVE PROBLEM / TEST", BLUE, Color.WHITE);
        addButton(journal, saveIssue);
        saveIssue.setOnClickListener(v -> saveJournalEntry());
        Button still = actionButton("MARK LAST PROBLEM: STILL HAPPENING", CARD2, TEXT);
        addButton(journal, still);
        still.setOnClickListener(v -> updateLastJournalEntry("STILL HAPPENING"));
        Button fixed = actionButton("MARK LAST PROBLEM: FIXED", CARD2, TEXT);
        addButton(journal, fixed);
        fixed.setOnClickListener(v -> updateLastJournalEntry("FIXED"));
        Button advisorMessage = actionButton("MAKE A MESSAGE TO SEND THE ROOK", BLUE, Color.WHITE);
        addButton(journal, advisorMessage);
        advisorMessage.setOnClickListener(v -> copyAdvisorMessage());
        journalHistory = text("No saved tests yet.", 12, MUTED, false);
        LinearLayout.LayoutParams historyLp = new LinearLayout.LayoutParams(-1, -2);
        historyLp.topMargin = dp(12);
        journal.addView(journalHistory, historyLp);
        refreshJournal();

        TextView footer = text("THE ROOK  ·  VERSION 2.0", 11, MUTED, true);
        footer.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams fl = new LinearLayout.LayoutParams(-1, -2);
        fl.topMargin = dp(18);
        page.addView(footer, fl);
        setContentView(scroll);
    }

    private LinearLayout card(LinearLayout parent) {
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(16), dp(15), dp(16), dp(16));
        box.setBackground(shape(CARD, 18));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.bottomMargin = dp(14);
        parent.addView(box, lp);
        return box;
    }

    private EditText input(LinearLayout parent, String hint, int value) {
        EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setText(String.valueOf(value));
        e.setHint(hint);
        e.setHintTextColor(MUTED);
        e.setTextColor(TEXT);
        e.setTextSize(14);
        e.setInputType(InputType.TYPE_CLASS_NUMBER);
        e.setPadding(dp(12), 0, dp(12), 0);
        e.setBackground(shape(CARD2, 10));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(48));
        lp.topMargin = dp(9);
        parent.addView(e, lp);
        return e;
    }

    private void addButton(LinearLayout parent, Button b) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(48));
        lp.topMargin = dp(8);
        parent.addView(b, lp);
    }

    private Button actionButton(String label, int fill, int foreground) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(13);
        b.setTextColor(foreground);
        b.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        b.setAllCaps(false);
        b.setStateListAnimator(null);
        b.setBackground(shape(fill, 12));
        return b;
    }

    private TextView text(String value, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private GradientDrawable shape(int color, int radius) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(radius));
        return d;
    }

    private int dp(float value) { return (int)(value * getResources().getDisplayMetrics().density + .5f); }

    private void saveSettings() {
        int x = bounded(xInput, 50, 0, 100);
        int y = bounded(yInput, 80, 0, 100);
        int hold = bounded(holdInput, 700, 50, 2500);
        int interval = bounded(intervalInput, 5000, 1500, 60000);
        prefs.edit().putInt("x", x).putInt("y", y).putInt("hold", hold).putInt("interval", interval).apply();
        if (RookAccessibilityService.instance != null) RookAccessibilityService.instance.reloadSettings();
    }

    private int bounded(EditText e, int fallback, int min, int max) {
        try { return Math.max(min, Math.min(max, Integer.parseInt(e.getText().toString().trim()))); }
        catch (Exception ignored) { return fallback; }
    }

    private void saveJournalEntry() {
        String body = issueInput == null ? "" : issueInput.getText().toString().trim();
        if (body.isEmpty()) {
            Toast.makeText(this, "Describe the problem or test first", Toast.LENGTH_SHORT).show();
            return;
        }
        String stamp = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm", java.util.Locale.getDefault()).format(new java.util.Date());
        String old = prefs.getString("journal", "");
        String next = (old.isEmpty() ? "" : old + "\n") + "[" + stamp + "] [NEW / UNVERIFIED] " + body.replace("\n", " ");
        prefs.edit().putString("journal", next).apply();
        issueInput.setText("");
        refreshJournal();
        Toast.makeText(this, "Test saved on this device", Toast.LENGTH_SHORT).show();
    }

    private void updateLastJournalEntry(String state) {
        String old = prefs.getString("journal", "");
        if (old.isEmpty()) {
            Toast.makeText(this, "Save a problem or test first", Toast.LENGTH_SHORT).show();
            return;
        }
        String[] lines = old.split("\n", -1);
        int i = lines.length - 1;
        String line = lines[i];
        int marker = line.indexOf("] ");
        if (marker >= 0) {
            int nextMarker = line.indexOf("] ", marker + 2);
            if (nextMarker >= 0) lines[i] = line.substring(0, marker + 2) + "[" + state + "] " + line.substring(nextMarker + 2);
            else lines[i] = line + " [" + state + "]";
        } else lines[i] = "[" + state + "] " + line;
        prefs.edit().putString("journal", android.text.TextUtils.join("\n", lines)).apply();
        refreshJournal();
    }

    private void copyAdvisorMessage() {
        String history = prefs.getString("journal", "");
        String prompt = "Please improve THE ROOK Fisch Android macro using this device's test history. "
                + "Compare the latest result with older entries, separate fixed problems from continuing problems, "
                + "and suggest the smallest testable code changes. Do not claim a fix is verified without a new test.\n\n"
                + "DEVICE HISTORY:\n" + (history.isEmpty() ? "No tests saved yet." : history);
        android.content.ClipboardManager clipboard = (android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
        clipboard.setPrimaryClip(android.content.ClipData.newPlainText("ROOK improvement request", prompt));
        Toast.makeText(this, "Improvement message copied", Toast.LENGTH_SHORT).show();
    }

    private void refreshJournal() {
        if (journalHistory == null) return;
        String history = prefs.getString("journal", "");
        if (history.isEmpty()) journalHistory.setText("No saved tests yet.");
        else journalHistory.setText(history);
    }

    private void refreshServiceState() {
        if (serviceState == null) return;
        boolean enabled = isServiceEnabled();
        serviceState.setText(enabled ? "ACCESSIBILITY SERVICE: ENABLED" : "ACCESSIBILITY SERVICE: NOT ENABLED");
        serviceState.setTextColor(enabled ? Color.rgb(116, 224, 167) : Color.rgb(255, 183, 105));
        if (RookAccessibilityService.instance != null && RookAccessibilityService.instance.isRunning()) macroState.setText("MACRO: RUNNING");
    }

    private boolean isServiceEnabled() {
        String enabled = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        String target = new ComponentName(this, RookAccessibilityService.class).flattenToString();
        return enabled != null && enabled.toLowerCase().contains(target.toLowerCase());
    }
}
