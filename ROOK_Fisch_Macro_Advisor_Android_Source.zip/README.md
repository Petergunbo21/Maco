# THE ROOK — Fisch Macro 2.0

Android project targeting the existing application ID `com.therook.fischmacro` and Android 7.0+.

## What's fixed / changed
- Adds a real `TYPE_ACCESSIBILITY_OVERLAY` window in `RookAccessibilityService`.
- Creates the floating GUI as soon as Android connects the enabled accessibility service.
- The panel can be dragged by its header, minimized to a small ROOK bubble, and reopened.
- Floating actions: Cast Once, Start, Pause, Stop.
- The main app has a cleaner dark dashboard, service status, cast X/Y, hold duration, and repeat interval settings.
- Keeps an on-device development journal, issue status labels, and a copyable ROOK improvement prompt.
- Uses the accessibility overlay type; a separate `SYSTEM_ALERT_WINDOW` permission is not required. The user must explicitly enable ROOK under Android Accessibility settings.

## Build using the existing Maco repository from a phone
The current `Petergunbo21/Maco` repository has workflows that look for the archive named `ROOK_Fisch_Macro_Advisor_Android_Source.zip`. Replace that file with this updated archive using the exact same filename, then commit the change to `main`. The existing GitHub Actions workflows should start automatically and upload a debug APK artifact. Open **Actions → latest successful THE ROOK build → Artifacts**, download the artifact ZIP, extract `app-debug.apk`, and install it.

If you choose to upload the extracted project instead of replacing the archive, use the included `.github/workflows/build.yml` and remove/disable the old archive-based workflow so it does not try to build the previous ZIP.

## First run
1. Open THE ROOK.
2. Tap **Enable Accessibility** and enable **ROOK Floating Macro** in Android Settings.
3. Return to THE ROOK. The floating panel should appear automatically. If not, tap **Show Floating Panel**.
4. Set X/Y to the approximate screen percentage of Fisch's cast control; save settings.
5. Open Fisch. Use **Cast Once** to verify the location. Then use **Start** and test the loop.

## Limits
This build sends a timed gesture at one configured coordinate. It does not recognize Fisch's SHAKE prompt or track the moving fish bar; those steps remain manual. Screen coordinates may need calibration for different layouts or orientations.

## Update/install note
The app ID is kept compatible with the existing THE ROOK package. A debug APK built on a new GitHub runner may have a different signing key from an earlier APK; Android may require uninstalling the prior version before installing the new one. Export any app-local history first if preserving it matters.
